const styles = {
    bg: {
      background: `url('/imgs/star_background.jfif')`,
    },
    bg_clr_1: {
      backgroundColor: '#FFC917'
    },
    clr_1:{
      color: '#FFC917'
    },
    btn: {
      padding:'5px 10px 10px 10px',
      borderRadius: '10px',
      color: '#000',
      margin: '20px 0px'
    }
};

export default styles;